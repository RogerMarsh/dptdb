// Copied from ../sample projects/HelloWorld! in DPT_V2R23_SOURCE_DBMS
// stdafx.cpp : source file that includes just the standard includes
//	dptdb.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

