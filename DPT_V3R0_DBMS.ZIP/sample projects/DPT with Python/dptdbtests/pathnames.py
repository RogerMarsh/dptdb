#pathnames.py
#Copyright 2008 Roger Marsh
#See www.dptoolkit.com for details of DPT
#License: DPToolkit license

"""Pathnames used in sample deferred update code."""

import os.path

homepath = os.path.abspath('data')
dptsys = os.path.join(homepath, 'sys')
dufolder = os.path.join(dptsys, 'dufolder')

games = os.path.join(homepath, 'games.dpt')
positions = os.path.join(homepath, 'positions.dpt')

parms = os.path.join(dptsys, 'parms.ini')
msgctl = os.path.join(dptsys, 'msgctl.ini')
sysprint = os.path.join(dptsys, 'sysprint.txt')
audit = os.path.join(dptsys, 'audit.txt')

duparms = os.path.join(dufolder, 'parms.ini')
dumsgctl = os.path.join(dufolder, 'msgctl.ini')
dusysprint = os.path.join(dufolder, 'sysprint.txt')
duaudit = os.path.join(dufolder, 'audit.txt')
duauditapi = os.path.join(dufolder, 'auditapi.txt')

logonname = 'store'
dulogonname = 'dustore'
