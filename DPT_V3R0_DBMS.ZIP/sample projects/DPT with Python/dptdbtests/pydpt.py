#pydpt.py
#Copyright 2007 - 2008 Roger Marsh
#See www.dptoolkit.com for details of DPT
#License: DPToolkit license

"""Sample code to do deferred and non-deferred updates.

The files are created and some records created without deferring index updates.
Before and after the non-deferred update record creation some of the possible
styles of deferred update are done by subprocesses.
"""

if __name__=='__main__':

    import os.path
    import subprocess

    # Syntax of print statement changes at Python 3.0 so hide these in exec()
    # Not recommended for production code.
    import sys
    pyversion3 = False
    if sys.version_info[:1] >= (3,):
        pyversion3 = True
    del sys
    
    import dptdb.dptapi as dptapi

    import pathnames

    # Create the files. Ensure checkpoint.ckp file and #SEQTEMP folder
    # are created in correct folder (change current working directory)
    if not os.path.exists(pathnames.homepath):
        os.makedirs(pathnames.homepath)
    if not os.path.exists(pathnames.dptsys):
        os.makedirs(pathnames.dptsys)

    pycwd = os.getcwd()
    os.chdir(pathnames.dptsys)
    ds = dptapi.APIDatabaseServices(
        pathnames.sysprint,
        pathnames.logonname,
        pathnames.parms,
        pathnames.msgctl,
        pathnames.audit)
    os.chdir(pycwd)

    ds.Allocate('GAMES', pathnames.games, dptapi.FILEDISP_COND)
    ds.Create('GAMES',
              5000,
              10,
              -1,
              -1,
              5000,
              -1,
              -1,
              dptapi.FILEORG_UNORD_RRN)
    csg = dptapi.APIContextSpecification('GAMES')
    ds.Allocate('POSITION', pathnames.positions, dptapi.FILEDISP_COND)
    ds.Create('POSITION',
              2000,
              200,
              -1,
              -1,
              5000,
              -1,
              -1,
              dptapi.FILEORG_UNORD_RRN)
    csp = dptapi.APIContextSpecification('POSITION')
    csgoc = ds.OpenContext(csg)
    csgoc.Initialize()
    fagame = dptapi.APIFieldAttributes()
    csgoc.DefineField('GAME', fagame)
    faposition = dptapi.APIFieldAttributes()
    faposition.SetOrderedFlag()
    csgoc.DefineField('POSITION', faposition)
    fagamenumber = dptapi.APIFieldAttributes()
    fagamenumber.SetFloatFlag()
    fagamenumber.SetOrderedFlag()
    fagamenumber.SetOrdNumFlag()
    csgoc.DefineField('GAMENUMBER', fagamenumber)
    fainvgamenumber = dptapi.APIFieldAttributes()
    fainvgamenumber.SetInvisibleFlag()
    fainvgamenumber.SetOrderedFlag()
    fainvgamenumber.SetOrdNumFlag()
    csgoc.DefineField('INVGAMENUMBER', fainvgamenumber)
    fainvgamecount = dptapi.APIFieldAttributes()
    fainvgamecount.SetInvisibleFlag()
    fainvgamecount.SetOrderedFlag()
    csgoc.DefineField('INVGAMECOUNT', fainvgamecount)
    fafltordcharcount = dptapi.APIFieldAttributes()
    fafltordcharcount.SetFloatFlag()
    fafltordcharcount.SetOrderedFlag()
    csgoc.DefineField('FLTORDCHARCOUNT', fafltordcharcount)
    fastrordnumcount = dptapi.APIFieldAttributes()
    fastrordnumcount.SetOrderedFlag()
    fastrordnumcount.SetOrdNumFlag()
    csgoc.DefineField('STRORDNUMCOUNT', fastrordnumcount)
    fastr = dptapi.APIFieldAttributes()
    csgoc.DefineField('STRCOUNT', fastr)
    faflt = dptapi.APIFieldAttributes()
    faflt.SetFloatFlag()
    csgoc.DefineField('FLTCOUNT', faflt)
    cspoc = ds.OpenContext(csp)
    cspoc.Initialize()
    fagamemove = dptapi.APIFieldAttributes()
    fagamemove.SetOrderedFlag()
    cspoc.DefineField('GAMEMOVE', fagamemove)
    fapiecesquare = dptapi.APIFieldAttributes()
    fapiecesquare.SetOrderedFlag()
    cspoc.DefineField('PIECESQUARE', fapiecesquare)
    ds.CloseContext(csgoc)
    ds.CloseContext(cspoc)
    ds.Free('GAMES')
    ds.Free('POSITION')

    # Do some deferred updates
    sp = subprocess.Popen(['pythonw', 'loadDefaultapi.py'])
    sp.wait()

    # Do some non-deferred updates
    ds.Allocate('GAMES', pathnames.games, dptapi.FILEDISP_OLD)
    ds.Allocate('POSITION', pathnames.positions, dptapi.FILEDISP_OLD)
    csgoc = ds.OpenContext(csg)
    cspoc = ds.OpenContext(csp)

    gfieldvalue = dptapi.APIFieldValue()
    grecordcopy = dptapi.APIStoreRecordTemplate()
    gAssign = gfieldvalue.Assign
    pfieldvalue = dptapi.APIFieldValue()
    precordcopy = dptapi.APIStoreRecordTemplate()
    pAssign = pfieldvalue.Assign
    gpvalue = 'NotDeferred'
    
    def Store():
        #For stepping over in debug mode
        for i in range(2000):
            pfv = []
            pfv.append(('GAME', 'game score' + str(i) + '1'))
            pfv.append(('GAME', 'game score' + str(i) + '2'))
            pfv.append(('POSITION', gpvalue))
            pfv.append(('GAMENUMBER', i))
            pfv.append(('INVGAMENUMBER', i + 0.6))
            pfv.append(('INVGAMECOUNT', str(i + 0.7)))
            pfv.append(('FLTORDCHARCOUNT', i + 0.8))
            pfv.append(('FLTORDCHARCOUNT', -i - 0.8))
            pfv.append(('STRORDNUMCOUNT', str(i + 0.9)))
            pfv.append(('STRORDNUMCOUNT', str(-i - 0.9)))
            pfv.append(('STRCOUNT', str(i)))
            pfv.append(('FLTCOUNT', float(i)))
            for j in range(8):
                pfv.append(('POSITION', str(i) + 'x' +str(j)))

            for field, value in pfv:
                gAssign(value)
                grecordcopy.Append(field, gfieldvalue)
            recnum = csgoc.StoreRecord(grecordcopy)
            grecordcopy.Clear()

            for k in range(10):
                psfv = []
                psfv.append(('GAMEMOVE', str(i)))
                psfv.append(('GAMEMOVE', gpvalue))
                psfv.append(('PIECESQUARE', 'b3'))
                psfv.append(('PIECESQUARE', 'k7'))
                psfv.append(('PIECESQUARE', str(k)))

                for field, value in psfv:
                    pAssign(value)
                    precordcopy.Append(field, pfieldvalue)
                recnum = cspoc.StoreRecord(precordcopy)
                precordcopy.Clear()

    Store()

    ds.CloseContext(csgoc)
    ds.CloseContext(cspoc)
    ds.Free('GAMES')
    ds.Free('POSITION')

    # Do some more deferred updates
    sp = subprocess.Popen(['pythonw', 'loadNoPadNoCRLFapi.py'])
    sp.wait()
    sp = subprocess.Popen(['pythonw', 'loadSingleStepapi.py'])
    sp.wait()

    # Do some finds etc
    ds.Allocate('GAMES', pathnames.games, dptapi.FILEDISP_OLD)
    ds.Allocate('POSITION', pathnames.positions, dptapi.FILEDISP_OLD)
    csgoc = ds.OpenContext(csg)
    cspoc = ds.OpenContext(csp)

    fv = dptapi.APIFieldValue(gpvalue)
    gfs1 = csgoc.FindRecords()
    gfs2 = csgoc.FindRecords('POSITION', dptapi.FD_EQ, fv)
    gfs3 = csgoc.FindRecords('POSITION', dptapi.FD_NOT_EQ, fv)
    if pyversion3:
        exec("print('GAMES all records', gfs1.Count())")
        exec("print('GAMES non-deferred records', gfs2.Count())")
        exec("print('GAMES deferred records', gfs3.Count())")
    else:
        exec("print 'GAMES all records', gfs1.Count()")
        exec("print 'GAMES non-deferred records', gfs2.Count()")
        exec("print 'GAMES deferred records', gfs3.Count()")
    csgoc.DestroyRecordSet(gfs1)
    csgoc.DestroyRecordSet(gfs2)
    csgoc.DestroyRecordSet(gfs3)

    pfs1 = cspoc.FindRecords()
    pfs2 = cspoc.FindRecords('GAMEMOVE', dptapi.FD_EQ, fv)
    pfs3 = cspoc.FindRecords('GAMEMOVE', dptapi.FD_NOT_EQ, fv)
    if pyversion3:
        exec("print('POSITION all records', pfs1.Count())")
        exec("print('POSITION non-deferred records', pfs2.Count())")
        exec("print('POSITION deferred records', pfs3.Count())")
    else:
        exec("print 'POSITION all records', pfs1.Count()")
        exec("print 'POSITION non-deferred records', pfs2.Count()")
        exec("print 'POSITION deferred records', pfs3.Count()")
    cspoc.DestroyRecordSet(pfs1)
    cspoc.DestroyRecordSet(pfs2)
    cspoc.DestroyRecordSet(pfs3)
    
    ds.CloseContext(csgoc)
    ds.CloseContext(cspoc)
    ds.Free('GAMES')
    ds.Free('POSITION')

    # Destroy the APIDatabaseServices object and ensure the
    # checkpoint.ckp file and #SEQTEMP folder are removed.
    pycwd = os.getcwd()
    os.chdir(pathnames.dptsys)
    ds.Destroy()
    os.chdir(pycwd)
