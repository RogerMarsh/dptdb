#loadNoPadNoCRLFapi.py
#Copyright 2007 - 2008 Roger Marsh
#See www.dptoolkit.com for details of DPT
#License: DPToolkit license

"""Sample DU_FORMAT_NOPAD | DU_FORMAT_NOCRLF multi-step deferred update code.

This module is run as a subprocess from pydpt.py but can be run independently
if the files already exist.
"""

if __name__=='__main__':

    import loaddptapi

    loaddptapi.Load(loaddptapi.loadNoPadNoCRLFAPI)
