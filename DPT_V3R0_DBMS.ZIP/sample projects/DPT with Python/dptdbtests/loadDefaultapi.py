#loadDefaultapi.py
#Copyright 2007 - 2008 Roger Marsh
#See www.dptoolkit.com for details of DPT
#License: DPToolkit license

"""Sample code using the DU_FORMAT_DEFAULT style multi-step deferred update.

This module is run as a subprocess from pydpt.py but can be run independently
if the files already exist.
"""

if __name__=='__main__':

    import loaddptapi

    loaddptapi.Load(loaddptapi.loadDefaultAPI)
