#loadSingleStepapi.py
#Copyright 2009 Roger Marsh
#See www.dptoolkit.com for details of DPT
#License: DPToolkit license

"""Sample code using single-step deferred update.

This module is run as a subprocess from pydpt.py but can be run independently
if the files already exist.
"""

if __name__=='__main__':

    import loaddptssapi

    loaddptssapi.Load(loaddptssapi.loadSingleStepAPI)
