#loaddptapi.py
#Copyright 2007 - 2008 Roger Marsh
#See www.dptoolkit.com for details of DPT
#License: DPToolkit license

"""Sample code to store records using multi-step deferred updates.

Use either DU_FORMAT_NOCRLF | DU_FORMAT_NOPAD or DU_FORMAT_DEFAULT style
multi-step deferred updates.

Use python to sort and merge deferred updates into two sequential files
then call ApplyDeferredUpdates to do the deferred updates.
"""

import sys
import os.path
import os

import dptdb.dptapi as dptapi

sys.path.insert(
    0,
    os.path.join(os.path.split(os.getcwd())[0], 'dptdbsamples'))

import rmstorerecordapi
import pathnames

loadNoPadNoCRLFAPI = 4
loadDefaultAPI = 5

def Load(style):

    if style not in (loadDefaultAPI, loadNoPadNoCRLFAPI):
        return

    try:
        os.mkdir(pathnames.dufolder)
    except:
        pass

    if not os.path.exists(pathnames.duparms):
        pf = open(pathnames.duparms, 'w')
        try:
            pf.write("RCVOPT=X'00' " + os.linesep)
            pf.write("MAXBUF=200 " + os.linesep)
        finally:
            pf.close()

    try:
        os.mkdir(os.path.join(pathnames.dufolder, 'GAMES'))
    except:
        pass
    try:
        os.mkdir(os.path.join(pathnames.dufolder, 'POSITION'))
    except:
        pass
    gsr = rmstorerecordapi.rmStoreRecord(pathnames.dufolder, 300000)
    psr = rmstorerecordapi.rmStoreRecord(pathnames.dufolder, 300000)
    
    # Start selection code probably not present in real case
    if style == loadDefaultAPI:
        value = 'DefaultAPI'
    elif style == loadNoPadNoCRLFAPI:
        value = 'NoPadNoCRLFAPI'
    if style == loadDefaultAPI:
        gsrSet = gsr.SetDefault
    elif style == loadNoPadNoCRLFAPI:
        gsrSet = gsr.SetNoPadNoCRLF
    if style == loadDefaultAPI:
        psrSet = psr.SetDefault
    elif style == loadNoPadNoCRLFAPI:
        psrSet = psr.SetNoPadNoCRLF
    # End selection code probably not present in real case
    
    # Change current working directory to prevent #SEQTEMP folder
    # being created in folder containing python code. Here just put
    # this folder with the rest of the files.
    pycwd = os.getcwd()
    os.chdir(pathnames.dufolder)
    ds = dptapi.APIDatabaseServices(
        pathnames.dusysprint,
        pathnames.dulogonname,
        pathnames.duparms,
        pathnames.dumsgctl,
        pathnames.duauditapi)
    sf = ds.SeqServs()
    os.chdir(pycwd)
    
    # Use the calls set in selection code
    gsrSet(ds, sf, 'GAMES', os.path.abspath(pathnames.games))
    psrSet(ds, sf, 'POSITION', os.path.abspath(pathnames.positions))

    # StoreRecord usage is same in all cases
    def Store():
        #For stepping over in debug mode
        for i in range(2000):
            pfv = []
            pfv.append(('GAME', 'game score' + str(i) + '1'))
            pfv.append(('GAME', 'game score' + str(i) + '2'))
            pfv.append(('POSITION', value))
            pfv.append(('GAMENUMBER', i))
            pfv.append(('INVGAMENUMBER', i + 0.6))
            pfv.append(('INVGAMECOUNT', str(i + 0.7)))
            pfv.append(('FLTORDCHARCOUNT', i + 0.8))
            pfv.append(('FLTORDCHARCOUNT', -i - 0.8))
            pfv.append(('STRORDNUMCOUNT', str(i + 0.9)))
            pfv.append(('STRORDNUMCOUNT', str(-i - 0.9)))
            pfv.append(('STRCOUNT', str(i)))
            pfv.append(('FLTCOUNT', float(i)))
            for j in range(8):
                pfv.append(('POSITION', str(i) + 'x' +str(j)))
            gsr.StoreRecord(pfv)
            for k in range(10):
                psfv = []
                psfv.append(('GAMEMOVE', str(i)))
                psfv.append(('GAMEMOVE', value))
                psfv.append(('PIECESQUARE', 'b3'))
                psfv.append(('PIECESQUARE', 'k7'))
                psfv.append(('PIECESQUARE', str(k)))
                psr.StoreRecord(psfv)

    Store()

    gsr.DoDeferredUpdates(ds, sf)
    psr.DoDeferredUpdates(ds, sf)
    gsr.EndDeferredUpdates(ds, sf)
    psr.EndDeferredUpdates(ds, sf)

    # Change current working directory to that containing #SEQTEMP
    # folder so that #SEQTEMP is deleted by ds.Destroy()
    pycwd = os.getcwd()
    os.chdir(pathnames.dufolder)
    ds.Destroy()
    os.chdir(pycwd)
    
    try:
        os.rmdir(os.path.join(pathnames.dufolder, 'GAMES'))
    except:
        pass
    try:
        os.rmdir(os.path.join(pathnames.dufolder, 'POSITION'))
    except:
        pass
    try:
        os.rmdir(pathnames.dufolder)
    except:
        pass
    
