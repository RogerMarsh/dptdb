#loaddptssapi.py
#Copyright 2007 - 2008 Roger Marsh
#See www.dptoolkit.com for details of DPT
#License: DPToolkit license

"""Sample code to store records using single-step deferred update."""

import sys
import os.path
import os

import dptdb.dptapi as dptapi

sys.path.insert(
    0,
    os.path.join(os.path.split(os.getcwd())[0], 'dptdbsamples'))

import rmstorerecordssapi
import pathnames

loadSingleStepAPI = 6

def Load(style):

    if style not in (loadSingleStepAPI,):
        return

    try:
        os.mkdir(pathnames.dufolder)
    except:
        pass

    if not os.path.exists(pathnames.duparms):
        pf = open(pathnames.duparms, 'w')
        try:
            pf.write("RCVOPT=X'00' " + os.linesep)
            pf.write("MAXBUF=200 " + os.linesep)
        finally:
            pf.close()

    try:
        os.mkdir(os.path.join(pathnames.dufolder, 'GAMES'))
    except:
        pass
    try:
        os.mkdir(os.path.join(pathnames.dufolder, 'POSITION'))
    except:
        pass
    gsr = rmstorerecordssapi.rmStoreRecord(pathnames.dufolder)
    psr = rmstorerecordssapi.rmStoreRecord(pathnames.dufolder)
    
    # Start selection code probably not present in real case
    if style == loadSingleStepAPI:
        value = 'SingleStepAPI'
    # End selection code probably not present in real case
    
    # Change current working directory to prevent #SEQTEMP folder
    # being created in folder containing python code. Here just put
    # this folder with the rest of the files."""
    pycwd = os.getcwd()
    os.chdir(pathnames.dufolder)
    ds = dptapi.APIDatabaseServices(
        pathnames.dusysprint,
        pathnames.dulogonname,
        pathnames.duparms,
        pathnames.dumsgctl,
        pathnames.duauditapi)
    os.chdir(pycwd)
    
    gsr.SetDefault(ds, 'GAMES', os.path.abspath(pathnames.games))
    psr.SetDefault(ds, 'POSITION', os.path.abspath(pathnames.positions))

    # StoreRecord usage is same in all cases
    def Store():
        #For stepping over in debug mode
        for i in range(2000):
            pfv = []
            pfv.append(('GAME', 'game score' + str(i) + '1'))
            pfv.append(('GAME', 'game score' + str(i) + '2'))
            pfv.append(('POSITION', value))
            pfv.append(('GAMENUMBER', i))
            pfv.append(('INVGAMENUMBER', i + 0.6))
            pfv.append(('INVGAMECOUNT', str(i + 0.7)))
            pfv.append(('FLTORDCHARCOUNT', i + 0.8))
            pfv.append(('FLTORDCHARCOUNT', -i - 0.8))
            pfv.append(('STRORDNUMCOUNT', str(i + 0.9)))
            pfv.append(('STRORDNUMCOUNT', str(-i - 0.9)))
            pfv.append(('STRCOUNT', str(i)))
            pfv.append(('FLTCOUNT', float(i)))
            for j in range(8):
                pfv.append(('POSITION', str(i) + 'x' +str(j)))
            gsr.StoreRecord(pfv)
            for k in range(10):
                psfv = []
                psfv.append(('GAMEMOVE', str(i)))
                psfv.append(('GAMEMOVE', value))
                psfv.append(('PIECESQUARE', 'b3'))
                psfv.append(('PIECESQUARE', 'k7'))
                psfv.append(('PIECESQUARE', str(k)))
                psr.StoreRecord(psfv)

    Store()

    gsr.DoDeferredUpdates(ds)
    psr.DoDeferredUpdates(ds)
    gsr.EndDeferredUpdates(ds)
    psr.EndDeferredUpdates(ds)

    # Change current working directory to that containing #SEQTEMP
    # folder so that #SEQTEMP is deleted by ds.Destroy()
    pycwd = os.getcwd()
    os.chdir(pathnames.dufolder)
    ds.Destroy()
    os.chdir(pycwd)
    
    try:
        os.rmdir(os.path.join(pathnames.dufolder, 'GAMES'))
    except:
        pass
    try:
        os.rmdir(os.path.join(pathnames.dufolder, 'POSITION'))
    except:
        pass
    try:
        os.rmdir(pathnames.dufolder)
    except:
        pass
    
