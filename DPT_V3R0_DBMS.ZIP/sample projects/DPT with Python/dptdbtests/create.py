#create.py
#Copyright 2009 Roger Marsh
#See www.dptoolkit.com for details of DPT
#License: DPToolkit license

"""Create files for sample code.

This module just creates the files so the multi-step and single-step deferred
update modules can be run separately against a new file and so on.
"""

if __name__=='__main__':

    import os.path
    import subprocess

    import dptdb.dptapi as dptapi

    import pathnames
    
    # Create the files. Ensure checkpoint.ckp file and #SEQTEMP folder
    # are created in correct folder (change current working directory)
    if not os.path.exists(pathnames.homepath):
        os.makedirs(pathnames.homepath)
    if not os.path.exists(pathnames.dptsys):
        os.makedirs(pathnames.dptsys)

    pycwd = os.getcwd()
    os.chdir(pathnames.dptsys)
    ds = dptapi.APIDatabaseServices(
        pathnames.sysprint,
        pathnames.logonname,
        pathnames.parms,
        pathnames.msgctl,
        pathnames.audit)
    os.chdir(pycwd)

    ds.Allocate('GAMES', pathnames.games, dptapi.FILEDISP_COND)
    ds.Create('GAMES',
              5000,
              10,
              -1,
              -1,
              5000,
              -1,
              -1,
              dptapi.FILEORG_UNORD_RRN)
    csg = dptapi.APIContextSpecification('GAMES')
    ds.Allocate('POSITION', pathnames.positions, dptapi.FILEDISP_COND)
    ds.Create('POSITION',
              2000,
              200,
              -1,
              -1,
              5000,
              -1,
              -1,
              dptapi.FILEORG_UNORD_RRN)
    csp = dptapi.APIContextSpecification('POSITION')
    csgoc = ds.OpenContext(csg)
    csgoc.Initialize()
    fagame = dptapi.APIFieldAttributes()
    csgoc.DefineField('GAME', fagame)
    faposition = dptapi.APIFieldAttributes()
    faposition.SetOrderedFlag()
    csgoc.DefineField('POSITION', faposition)
    fagamenumber = dptapi.APIFieldAttributes()
    fagamenumber.SetFloatFlag()
    fagamenumber.SetOrderedFlag()
    fagamenumber.SetOrdNumFlag()
    csgoc.DefineField('GAMENUMBER', fagamenumber)
    fainvgamenumber = dptapi.APIFieldAttributes()
    fainvgamenumber.SetInvisibleFlag()
    fainvgamenumber.SetOrderedFlag()
    fainvgamenumber.SetOrdNumFlag()
    csgoc.DefineField('INVGAMENUMBER', fainvgamenumber)
    fainvgamecount = dptapi.APIFieldAttributes()
    fainvgamecount.SetInvisibleFlag()
    fainvgamecount.SetOrderedFlag()
    csgoc.DefineField('INVGAMECOUNT', fainvgamecount)
    fafltordcharcount = dptapi.APIFieldAttributes()
    fafltordcharcount.SetFloatFlag()
    fafltordcharcount.SetOrderedFlag()
    csgoc.DefineField('FLTORDCHARCOUNT', fafltordcharcount)
    fastrordnumcount = dptapi.APIFieldAttributes()
    fastrordnumcount.SetOrderedFlag()
    fastrordnumcount.SetOrdNumFlag()
    csgoc.DefineField('STRORDNUMCOUNT', fastrordnumcount)
    fastr = dptapi.APIFieldAttributes()
    csgoc.DefineField('STRCOUNT', fastr)
    faflt = dptapi.APIFieldAttributes()
    faflt.SetFloatFlag()
    csgoc.DefineField('FLTCOUNT', faflt)
    cspoc = ds.OpenContext(csp)
    cspoc.Initialize()
    fagamemove = dptapi.APIFieldAttributes()
    fagamemove.SetOrderedFlag()
    cspoc.DefineField('GAMEMOVE', fagamemove)
    fapiecesquare = dptapi.APIFieldAttributes()
    fapiecesquare.SetOrderedFlag()
    cspoc.DefineField('PIECESQUARE', fapiecesquare)
    ds.CloseContext(csgoc)
    ds.CloseContext(cspoc)
    ds.Free('GAMES')
    ds.Free('POSITION')

    # Do some finds etc
    ds.Allocate('GAMES', pathnames.games, dptapi.FILEDISP_OLD)
    ds.Allocate('POSITION', pathnames.positions, dptapi.FILEDISP_OLD)
    csgoc = ds.OpenContext(csg)
    cspoc = ds.OpenContext(csp)

    gfs1 = csgoc.FindRecords()
    print 'GAMES all records', gfs1.Count()
    csgoc.DestroyRecordSet(gfs1)

    pfs1 = cspoc.FindRecords()
    print 'POSITION all records', pfs1.Count()
    cspoc.DestroyRecordSet(pfs1)
    
    ds.CloseContext(csgoc)
    ds.CloseContext(cspoc)
    ds.Free('GAMES')
    ds.Free('POSITION')

    # Destroy the APIDatabaseServices object and ensure the
    # checkpoint.ckp file and #SEQTEMP folder are removed.
    pycwd = os.getcwd()
    os.chdir(pathnames.dptsys)
    ds.Destroy()
    os.chdir(pycwd)
