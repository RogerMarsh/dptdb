
#if !defined BB_CONST_UTIL
#define BB_CONST_UTIL

//These are defines so they can be contatenated in C string constants
#define BB_CAPITAL_LETTERS		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#define BB_LOWERCASE_LETTERS	"abcdefghijklmnopqrstuvwxyz"
#define BB_DIGITS				"0123456789"

//Occasionally useful for strchr or string::find().  Zero has to be located separately
//in such cases for obvious reasons.
#define BB_ASCII_1_31			"\x01\x02\x03\x04\x05\x06\x07\x08" \
								"\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10" \
								"\x11\x12\x13\x14\x15\x16\x17\x18" \
								"\x19\x1a\x1b\x1c\x1d\x1e\x1f"

#endif
