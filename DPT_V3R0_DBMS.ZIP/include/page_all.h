#ifndef BB_PAGE_ALL
#define BB_PAGE_ALL

//#include "page_F.h"	//FCT
//#include "page_B.h"  //table B
//#include "page_A.h"  //field attributes
//#include "page_T.h"  //b-tree nodes (all types now)
//#include "page_V.h"  //index inverted list
//#include "page_I.h"  //inverted list master records
//#include "page_M.h"  //index bit map
//#include "page_P.h"  //EBM bit map
//#include "page_E.h"  //EBM index
//#include "page_X.h"  //table D re-usable page

#endif
