//****************************************************************************************
// Stuff to do with emulation of M204 acces control features (LOGCTL, field security etc).
// Very rudimentary to begin with (and perhaps for always).
//****************************************************************************************

#if !defined(BB_ACCESS)
#define BB_ACCESS

#include <string> 
#include <vector> 
#include <map>

#include "filehandle.h"
#include "lockable.h"

namespace dpt {

class CoreServices;
namespace util {class BBStdioFile;}

class AccessController {
	static bool created;

	util::BBStdioFile* file;
	std::string filename;
	FileHandle alloc_handle;
	Lockable lock;

	std::string last_write_time;
	std::string last_write_user;

	struct CachedUserInfo {
		std::string name;
		std::string pwhash;
		unsigned int privs;
		CachedUserInfo() {}
		CachedUserInfo(const std::string& n) : name(n) {}
	};
	std::map<std::string, CachedUserInfo> cached_user_table;

	CachedUserInfo* LocateCachedInfo(const std::string&, bool = true);

	char* ptr;
	char* end;
	void AdvanceFilePointer(int delta) {ptr += delta; if (ptr > end) ThrowCorruptData();}

	void ThrowCorruptData();
	void RewriteFile(CoreServices*);
	std::string CalcCheckSum(const std::string&);

public:
	AccessController(CoreServices*);
	~AccessController();

	void CreateUser(CoreServices*, const std::string&);
	void DeleteUser(CoreServices*, const std::string&);

	void ChangeUserPassword(CoreServices*, const std::string&, const std::string&);
	void ChangeUserPrivs(CoreServices*, const std::string&, unsigned int);

	bool CheckUserPassword(const std::string&, const std::string&);
	unsigned int GetUserPrivs(const std::string&);

	std::vector<std::string> GetAllUserNames();
	std::vector<unsigned int> GetAllUserPrivs();
	std::vector<std::string> GetAllUserHashes();

	const std::string& LastUpdateUser() {LockingSentry ls(&lock); return last_write_user;}
	const std::string& LastUpdateTime() {LockingSentry ls(&lock); return last_write_time;}
};


} //close namespace

#endif
