//****************************************************************************************
//Interface to the DPT password file
//****************************************************************************************

#if !defined(BB_API_ACCESS)
#define BB_API_ACCESS

#include <string>
#include <vector>

namespace dpt {

class APICoreServices;
class AccessController;

class APIAccessController {
public:
	AccessController* target;
	APIAccessController(AccessController*);
	APIAccessController(const APIAccessController&);
	//-----------------------------------------------------------------------------------

	unsigned int GetUserPrivs(const std::string& name);
	bool CheckUserPassword(const std::string& name, const std::string& pwd);

	void CreateUser(const APICoreServices&, const std::string& name);
	void DeleteUser(const APICoreServices&, const std::string& name);

	void ChangeUserPassword(const APICoreServices&, 
							const std::string& name, const std::string& pwd);
	void ChangeUserPrivs(const APICoreServices&, 
							const std::string& name, unsigned int privs);

	//These return arrays ordered by user name
	std::vector<std::string> GetAllUserNames();
	std::vector<unsigned int> GetAllUserPrivs();
	std::vector<std::string> GetAllUserHashes();

	const std::string& LastUpdateUser();
	const std::string& LastUpdateTime();
};

} //close namespace

#endif
