
#if !defined(BB_DBFIELD)
#define BB_DBFIELD

namespace dpt {

	now in dbf_field


}	//close namespace

#endif
