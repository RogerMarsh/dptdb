DPT Source Code Accompanying Notes
==================================

- This directory contains notes which may prove helpful to build and/or use the code.  Please feed back any experiences you have, or code changes you make.

- Roger Marsh has written some fairly detailed notes about getting the source to compile/build using different toolsets.  The goal there was to use DPT from a python application, but a lot of the information is probably more generally applicable (e.g. DPT gets compiled with gcc/mingw).  These notes are with the associated project files in the "Sample Projects" directory. 

- The main DPT manuals (DBA guide, API programming guide, etc.) are not in the source code package - just download the separate zip file of docs.

- A fair amount of low-level technical documentation exists back at DPT HQ on some topics and may get included here over time.  Please get in touch if you have any specific interest areas, or indeed if you make any useful notes yourself which could be distributed.

