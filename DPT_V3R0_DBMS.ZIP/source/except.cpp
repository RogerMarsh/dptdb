
#include "stdafx.h"


#include "except.h"

namespace dpt { 

	void except() {}

} //close namespace
