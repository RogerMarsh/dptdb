
#include "stdafx.h"

#include "page_i.h" //#include "page_I.h" : V2.24 case is less interchangeable on *NIX - Roger M.

namespace dpt {

	void page_i() {}

} //close namespace
