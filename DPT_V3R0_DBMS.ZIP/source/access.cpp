
#include "stdafx.h"

#include "access.h"

//Utils
#include "dataconv.h"
#include "iowrappers.h"
#include "hash.h"
#include "winutil.h"
//API tiers
#include "sysfile.h"
#include "core.h"
//Diagnostics
#include "except.h"
#include "msg_core.h"
#include "msg_util.h"

namespace dpt {

bool AccessController::created = false;

static Hash_SHA1 hasher;
static int digest_length = Hash_SHA1::DIGEST_LENGTH;

//*****************************************************************************************
AccessController::AccessController(CoreServices* caller)
{
	if (created) 
		throw Exception(API_SINGLETON, "There can be only one access control file object");
	created = true;

	filename = "dptstat.dat";
	alloc_handle = SystemFile::Construct("+DPTSTAT", filename, BOOL_EXCL);

	char* buff = NULL;
	try {

		//Create an empty file if it's not there
		try {
			file = new util::BBStdioFile(filename.c_str(), util::STDIO_OLD);
		}
		catch (...) {
			file = new util::BBStdioFile(filename.c_str(), util::STDIO_NEW);
			RewriteFile(caller);
			return;
		}

		//Otherwise read the existing file data into our local cache
		int flength = file->FLength();

		//Overall length sanity check (header line is datetime + user name + CRLF)
		if (flength < digest_length + 30) 
			ThrowCorruptData();

		//Read it all in
		buff = new char[flength];
		file->Read(buff, flength);

		ptr = buff;
		end = buff + (flength - digest_length); //checksum position

		//Get header line information: last update time
		last_write_time = std::string(ptr, 24);
		AdvanceFilePointer(24);

		//...last update user
		int namelen = *(reinterpret_cast<int*>(ptr));
		AdvanceFilePointer(4);
		last_write_user = std::string(ptr, namelen);
		AdvanceFilePointer(namelen);
		AdvanceFilePointer(2);

		//Then read each user entry line
		while (ptr < end) {

			//User name
			int namelen = *(reinterpret_cast<int*>(ptr));
			AdvanceFilePointer(4);
			std::string name(ptr, namelen);
			AdvanceFilePointer(namelen);

			CachedUserInfo info(name);

			//Password digest
			info.pwhash = std::string(ptr, digest_length);
			AdvanceFilePointer(digest_length);

			//Priviliges
			info.privs = *(reinterpret_cast<unsigned int*>(ptr));
			AdvanceFilePointer(4);

			//Cache the info locally for fast lookup
			cached_user_table[name] = info;

			//Go past crlf
			AdvanceFilePointer(2);
		}

		if (ptr != end)
			ThrowCorruptData();

		//Finally validate the checksum
		std::string gotsum = std::string(ptr, digest_length);
		std::string calcsum = CalcCheckSum(std::string(buff, flength - digest_length));
		if (gotsum != calcsum)
			ThrowCorruptData();

		delete[] buff;
	}
	catch (...) {
		if (buff)
			delete[] buff;
		delete file;
		SystemFile::Destroy(alloc_handle);
		throw;
	}
}

//****************************************
void AccessController::ThrowCorruptData()
{
	throw Exception(ACCESS_CONTROL_BADDATA, "Access control file (dptstat) is corrupt");
}

//****************************************
AccessController::~AccessController()
{
	delete file;
	SystemFile::Destroy(alloc_handle);

	created = false;
}

//****************************************
std::string AccessController::CalcCheckSum(const std::string& s)
{
	//Make it a little bit more obscure than just a straight hash on the data
	std::string dummy = std::string("DUMMY").append(s).append("DUMMY");

	return hasher.Perform(dummy.c_str(), dummy.length());
}

//****************************************
void AccessController::RewriteFile(CoreServices* caller)
{
	last_write_time = win::GetCTime();
	last_write_user = caller->GetUserID();

	//Start with a header line
	std::string data = last_write_time;
	int namelen = last_write_user.length();
	data.append(std::string(reinterpret_cast<char*>(&namelen), 4));
	data.append(last_write_user);
	data.append("\r\n");

	//Then all the entry data
	std::map<std::string, CachedUserInfo>::iterator i;
	for (i = cached_user_table.begin(); i != cached_user_table.end(); i++) {

		//User name
		int namelen = i->first.length();
		data.append(std::string(reinterpret_cast<char*>(&namelen), 4));
		data.append(i->first);

		//PW hash
		data.append(i->second.pwhash);

		//Privs
		data.append(std::string(reinterpret_cast<char*>(&i->second.privs), 4));

		data.append("\r\n");
	}

	//And a final check sum
	data.append(CalcCheckSum(data));

	//Overwrite the file contents
	file->Chsize(data.length());
	file->Seek(0);
	file->Write(data.c_str(), data.length());
}

//****************************************
AccessController::CachedUserInfo* AccessController::LocateCachedInfo
(const std::string& name, bool throwit)
{
	std::map<std::string, CachedUserInfo>::iterator i = cached_user_table.find(name);
	if (i != cached_user_table.end())
		return &(i->second);

	if (throwit)
		throw Exception(USER_DOES_NOT_EXIST, std::string("User does not exist: ").append(name));
	else
		return NULL;
}

//****************************************
unsigned int AccessController::GetUserPrivs(const std::string& name) 
{
	LockingSentry ls(&lock);

	return LocateCachedInfo(name)->privs;
}

//****************************************
bool AccessController::CheckUserPassword
(const std::string& name, const std::string& checkee)
{
	LockingSentry ls(&lock);

	std::string checkee_hash = hasher.Perform(checkee.c_str(), checkee.length());
	return (LocateCachedInfo(name)->pwhash == checkee_hash);
}

//****************************************
void AccessController::CreateUser
(CoreServices* caller, const std::string& name)
{
	LockingSentry ls(&lock);

	if (LocateCachedInfo(name, false))
		throw Exception(USER_ALREADY_EXISTS, std::string("User already exists: ").append(name));

	CachedUserInfo info(name);

	//Set a default password here, although you would expect a better one to be
	//set almost immediately.  For example the LOGCTL command does that.
	static const std::string default_pw = "password";
	info.pwhash = hasher.Perform(default_pw.c_str(), default_pw.length());

	//Default privs is none
	info.privs = 0;

	cached_user_table[name] = info;

	RewriteFile(caller);
}

//****************************************
void AccessController::DeleteUser
(CoreServices* caller, const std::string& name)
{
	LockingSentry ls(&lock);

	LocateCachedInfo(name);
	cached_user_table.erase(name);

	RewriteFile(caller);
}

//****************************************
void AccessController::ChangeUserPassword
(CoreServices* caller, const std::string& name, const std::string& pw)
{
	LockingSentry ls(&lock);

	LocateCachedInfo(name)->pwhash = hasher.Perform(pw.c_str(), pw.length());

	RewriteFile(caller);
}

//****************************************
void AccessController::ChangeUserPrivs
(CoreServices* caller, const std::string& name, unsigned int p)
{
	LockingSentry ls(&lock);

	LocateCachedInfo(name)->privs = p;

	RewriteFile(caller);
}

//****************************************
std::vector<std::string> AccessController::GetAllUserNames()
{
	LockingSentry ls(&lock);
	std::vector<std::string> result;

	std::map<std::string, CachedUserInfo>::iterator i;
	for (i = cached_user_table.begin(); i != cached_user_table.end(); i++)
		result.push_back(i->first);

	return result;
}

//****************************************
std::vector<std::string> AccessController::GetAllUserHashes()
{
	LockingSentry ls(&lock);
	std::vector<std::string> result;

	std::map<std::string, CachedUserInfo>::iterator i;
	for (i = cached_user_table.begin(); i != cached_user_table.end(); i++)
		result.push_back(i->second.pwhash);

	return result;
}

//****************************************
std::vector<unsigned int> AccessController::GetAllUserPrivs()
{
	LockingSentry ls(&lock);
	std::vector<unsigned int> result;

	std::map<std::string, CachedUserInfo>::iterator i;
	for (i = cached_user_table.begin(); i != cached_user_table.end(); i++)
		result.push_back(i->second.privs);

	return result;
}

} //close namespace


