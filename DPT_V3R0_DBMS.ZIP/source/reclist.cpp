
#include "stdafx.h"

#include "reclist.h"

//Utils
//API Tiers
//Diagnostics

namespace dpt {

	void reclist() {}

} //close namespace


