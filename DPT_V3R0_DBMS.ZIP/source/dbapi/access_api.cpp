
#include "stdafx.h"

#include "dbapi\access.h"
#include "access.h"

#include "dbapi\core.h"

namespace dpt {

APIAccessController::APIAccessController(AccessController* t) 
: target(t) {}
APIAccessController::APIAccessController(const APIAccessController& t) 
: target(t.target) {}

//********************************************
unsigned int APIAccessController::GetUserPrivs(const std::string& name)
{
	return target->GetUserPrivs(name);
}

bool APIAccessController::CheckUserPassword
(const std::string& name, const std::string& pwd)
{
	return target->CheckUserPassword(name, pwd);
}


//********************************************
void APIAccessController::CreateUser
(const APICoreServices& core, const std::string& name)
{
	target->CreateUser(core.target, name);
}

void APIAccessController::DeleteUser
(const APICoreServices& core, const std::string& name)
{
	target->DeleteUser(core.target, name);
}


//********************************************
void APIAccessController::ChangeUserPassword
(const APICoreServices& core, const std::string& name, const std::string& pwd)
{
	target->ChangeUserPassword(core.target, name, pwd);
}

void APIAccessController::ChangeUserPrivs
(const APICoreServices& core, const std::string& name, unsigned int privs)
{
	target->ChangeUserPrivs(core.target, name, privs);
}


//********************************************
std::vector<std::string> APIAccessController::GetAllUserNames()
{
	return target->GetAllUserNames();
}

std::vector<unsigned int> APIAccessController::GetAllUserPrivs()
{
	return target->GetAllUserPrivs();
}

std::vector<std::string> APIAccessController::GetAllUserHashes()
{
	return target->GetAllUserHashes();
}


//********************************************
const std::string& APIAccessController::LastUpdateUser()
{
	return target->LastUpdateUser();
}

const std::string& APIAccessController::LastUpdateTime()
{
	return target->LastUpdateTime();
}


} //close namespace


