
#include "stdafx.h"

#include "atomback.h"

//Utils
//API Tiers
//Diagnostics

namespace dpt {

	void atomback() {}

} //close namespace


