
#include "stdafx.h"

#include "pageixval.h"

//Utils
//API tiers
//Diagnostics

namespace dpt {

	void pageixval() {}

} //close namespace
