
#include "stdafx.h"

#include "page_x.h" //#include "page_X.h" : V2.24 case is less interchangeable on *NIX - Roger M.

namespace dpt {

	void page_x() {}
	
} //close namespace
